import math
def tinh_S(x,n):
      S=pow(x*x+1,n)
      print(S)
x=int(input('nhập x:'))
n=int(input('nhập n:'))
tinh_S(x,n)