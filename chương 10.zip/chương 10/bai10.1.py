import math
print(max())
print(min())