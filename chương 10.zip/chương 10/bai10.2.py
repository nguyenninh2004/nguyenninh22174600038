import math
def tim_gia_tri_tuyet_doi(x):
      S= abs(x)
      print("|x|=",S)
x=int(input('Nhập x:'))
tim_gia_tri_tuyet_doi(x)      