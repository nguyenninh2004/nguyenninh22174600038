#In giá trị theo dấu của 1 số
def in_so(x):
      if x>0:
            print('# in ra 1')
      elif x<0:
            print('# in ra -1')
      else:
            print('0')
x=int(input('nhập x:'))
in_so(x)