#Tính S(n,x)
def tinh_S(n,x):
      S=(x*x+1)**n
      print("S=",S)
      return
x=int(input('nhập x:'))
n=int(input('nhập n:'))
tinh_S(n,x)