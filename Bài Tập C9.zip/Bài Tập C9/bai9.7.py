#Hàm trả về phần nguyên
def phan_nguyen(x,y):
      a=x//y
      print(a)
      return
x=float(input('nhập x:'))
y=float(input('nhập y:'))
phan_nguyen(x,y)